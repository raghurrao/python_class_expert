BEGIN TRANSACTION;
CREATE TABLE departments (
    dept_id INTEGER PRIMARY KEY AUTOINCREMENT,
    dept_name TEXT NOT NULL UNIQUE,
    location TEXT DEFAULT 'Headquarters'
);
INSERT INTO "departments" VALUES(1,'Engineering','Building A - Tech Hub');
INSERT INTO "departments" VALUES(2,'Data Science','Building B');
INSERT INTO "departments" VALUES(3,'Sales','Building C');
INSERT INTO "departments" VALUES(4,'Marketing','Building D');
CREATE TABLE employees (
    emp_id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    salary REAL CHECK (salary > 0),
    hire_date DATE DEFAULT (DATE('now')),
    dept_id INTEGER,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL
);
INSERT INTO "employees" VALUES(1,'Alice','Smith','alice@company.com',95000.0,'2026-08-27',1);
INSERT INTO "employees" VALUES(2,'Bob','Jones','bob@company.com',88000.0,'2026-08-27',1);
INSERT INTO "employees" VALUES(3,'Charlie','Brown','charlie@company.com',79200.0,'2026-08-27',2);
INSERT INTO "employees" VALUES(4,'Diana','Prince','diana@company.com',1.15500000000000014e+05,'2026-08-27',2);
INSERT INTO "employees" VALUES(5,'Evan','Wright','evan@company.com',65000.0,'2026-08-27',3);
INSERT INTO "employees" VALUES(6,'Fiona','Gallagher','fiona@company.com',120000.0,'2026-08-27',1);
INSERT INTO "employees" VALUES(7,'George','Martin','george@company.com',55000.0,'2026-08-27',NULL);
CREATE INDEX idx_emp_email ON employees(email);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('departments',5);
INSERT INTO "sqlite_sequence" VALUES('employees',7);
COMMIT;
